<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserRol extends Model
{
    //
    protected $table = 'role_user';
}
